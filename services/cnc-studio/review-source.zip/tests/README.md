# Reproduce CNC Studio 0.7.0 reviews

Extract this archive into the services/cnc-studio directory. It creates tests/.
Use Node.js 24+ and a recent Chrome with WebGL; Chrome 155 was tested.
The WASM helper reuses the shipped vendor/occt.wasm.gz.* assets and verifies SHA-256.
All STEP fixtures are synthetic. Python-reference data are recorded fixtures, not a new Python execution.

Run a local server: CNC_PORT=8897 node tests/serve-local.mjs
Start a dedicated Chrome with --headless=new --remote-debugging-port=9338
--user-data-dir=<your temporary profile> --enable-unsafe-swiftshader
http://127.0.0.1:8897/ . Use a new profile; keep existing browser sessions separate.

Then run, sequentially:

node tests/review-all.mjs 1
node tests/review-all.mjs 2
node tests/review-all.mjs 3

On PowerShell set the server variable with $env:CNC_PORT='8897'.
The runner uses ports 8897/9338, stores logs and checksums under tests/review-round-N,
and tests real browser file inputs/downloads and Worker/WASM/WebGL behavior.
The optional MiniLM model is mocked; external live inference is not tested.
Close only the server and browser processes you started when finished.
