// Real headless Chrome + browser Worker/WASM end-to-end acceptance.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
const endpoint=process.env.CNC_CDP_ENDPOINT||'http://127.0.0.1:9333';
const site='http://127.0.0.1:'+ (process.env.CNC_PORT||8892)+'/';
const pages=await (await fetch(endpoint+'/json')).json();
const page=pages.find(t=>t.type==='page'&&t.url.startsWith(site));
assert.ok(page,'No locally launched browser acceptance page');
const ws=new WebSocket(page.webSocketDebuggerUrl),pending=new Map(),errors=[];
let serial=0;
await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
ws.addEventListener('message',event=>{
 const msg=JSON.parse(event.data);
 if(msg.id){const item=pending.get(msg.id);if(!item)return;pending.delete(msg.id);msg.error?item.reject(Error(JSON.stringify(msg.error))):item.resolve(msg.result);}
 if(msg.method==='Runtime.exceptionThrown')errors.push(msg.params.exceptionDetails.text);
 if(msg.method==='Log.entryAdded'&&msg.params.entry.level==='error')errors.push(msg.params.entry.text+' '+(msg.params.entry.url||''));
});
function call(method,params={}){return new Promise((resolve,reject)=>{const id=++serial;pending.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}));setTimeout(()=>{if(pending.delete(id))reject(Error('CDP timeout '+method));},15000);});}
async function evaluate(expression){const r=await call('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.text+' '+JSON.stringify(r.exceptionDetails.exception?.description));return r.result.value;}
async function wait(condition,timeoutMs=90000){const until=Date.now()+timeoutMs;while(Date.now()<until){if(await evaluate(condition))return;await new Promise(r=>setTimeout(r,400));}throw Error('Browser timeout: '+condition+'; status='+await evaluate(`document.getElementById('toast').textContent`));}
const checks=[];
async function test(name,fn){await fn();checks.push(name);console.log('PASS',name);}
try{
 await call('Runtime.enable');await call('Log.enable');await call('Page.enable');
 await call('Emulation.setDeviceMetricsOverride',{width:1580,height:1050,deviceScaleFactor:1,mobile:false});
 await call('Page.navigate',{url:site});
 await test('page_initialized',async()=>{
  await wait(`document.getElementById('service')?.textContent.includes('0.7.0')`,30000);
  assert.equal(await evaluate(`document.getElementById('machining_mode').value`),'rough');
  assert.equal(await evaluate(`document.getElementById('fields').disabled`),true);
  assert.equal(await evaluate(`document.getElementById('source_mode').value`),'step');
 });
 await test('real_surface_step_import_worker_wasm',async()=>{
  await evaluate(`document.getElementById('surface-demo').click()`);
  await wait(`document.getElementById('filename').textContent.includes('Surface_trough') && !document.getElementById('fields').disabled`);
  assert.equal(await evaluate(`document.getElementById('machining_mode').value`),'surface');
  assert.ok((await evaluate(`document.getElementById('surface-status').textContent`)).includes('整合高度場'));
  assert.equal(await evaluate(`document.getElementById('tool').value`),'ball6');
  assert.equal(await evaluate(`document.getElementById('use_lite').disabled`),true);
 });
 await test('integrated_flat_rough_and_ball_finish_plan',async()=>{
  await evaluate(`document.getElementById('plan').click()`);
  await wait(`document.getElementById('status').textContent==='NC 草稿' && !document.getElementById('fields').disabled`);
  assert.ok(await evaluate(`document.getElementById('download').hasAttribute('href')`));
  const tasks=await evaluate(`document.getElementById('tasks').textContent`);
  assert.ok(tasks.includes('平刀')&&tasks.includes('球刀'));
 });
 await test('accepted_surface_nc_and_2d_3d_playback',async()=>{
  assert.ok(await evaluate(`document.getElementById('download').hasAttribute('href')`));
  const ncInfo=await evaluate(`(async()=>{const nc=await (await fetch(document.getElementById('download').href)).text();return {count:nc.split('\\n').filter(l=>/^G[01] X/.test(l)).length,t1:nc.includes('T01 M06'),t4:nc.includes('T04 M06')}})()`);
  const count=ncInfo.count;assert.equal(ncInfo.t1,true);assert.equal(ncInfo.t4,true);
  assert.ok(count>1000,'NC has surface toolpath blocks');
  for(const key of ['xy','xz','yz','3d']){
   assert.equal(await evaluate(`document.querySelector('[data-view="${key}"]').click();document.querySelector('[data-view="${key}"]').getAttribute('aria-selected')`),'true');
  }
  await evaluate(`document.getElementById('timeline').value=999;document.getElementById('timeline').dispatchEvent(new Event('input',{bubbles:true}))`);
  assert.ok((await evaluate(`document.getElementById('coordinates').textContent`)).includes('T4'));
 });
 const shot=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:true});
 fs.writeFileSync(new URL('./surface-ui-acceptance.png',import.meta.url),Buffer.from(shot.data,'base64'));
 await test('changing_setup_revokes_previous_nc',async()=>{
  await evaluate(`document.getElementById('surface_sample').value='1.2';document.getElementById('surface_sample').dispatchEvent(new Event('input',{bubbles:true}))`);
  assert.equal(await evaluate(`document.getElementById('status').textContent`),'待規劃');
  assert.equal(await evaluate(`document.getElementById('download').hasAttribute('href')`),false);
 });
 await test('legacy_rough_demo_still_functions',async()=>{
  await evaluate(`document.getElementById('machining_mode').value='rough';document.getElementById('machining_mode').dispatchEvent(new Event('change',{bubbles:true}));document.getElementById('demo').click()`);
  await wait(`document.getElementById('filename').textContent.includes('Demo_plate') && !document.getElementById('fields').disabled`);
  await evaluate(`document.getElementById('plan').click()`);
  await wait(`document.getElementById('status').textContent==='NC 草稿' && !document.getElementById('fields').disabled`);
  assert.equal(await evaluate(`document.getElementById('tool').value`),'em6');
  assert.equal(await evaluate(`document.getElementById('use_lite').disabled`),false);
 });
 await test('original_step_plan_can_simulate_stock_removal',async()=>{
  await evaluate(`document.getElementById('simulate-plan').click()`);
  await wait(`!document.getElementById('sim-final').disabled`,90000);
  assert.ok((await evaluate(`document.getElementById('material-summary').textContent`)).includes('mm³'));
  await evaluate(`document.getElementById('sim-final').click()`);
  assert.equal(await evaluate(`document.getElementById('status').textContent`),'除料後工件');
 });
 await test('gcode_mode_selects_independent_stock_and_material',async()=>{
  await evaluate(`document.getElementById('source_mode').value='gcode';document.getElementById('source_mode').dispatchEvent(new Event('change',{bubbles:true}))`);
  assert.equal(await evaluate(`document.getElementById('setup').hidden`),true);
  assert.equal(await evaluate(`document.getElementById('gcode-form').hidden`),false);
  await evaluate(`document.getElementById('gcode-demo').click()`);
  await wait(`document.getElementById('gcode-name').textContent.includes('arc-removal-demo')`,30000);
  await evaluate(`document.getElementById('gcode-material').value='s45c';document.getElementById('gcode-material').dispatchEvent(new Event('input',{bubbles:true}))`);
  assert.equal(await evaluate(`document.getElementById('gcode-machine').value`),'vmc400');
 });
 await test('live_gcode_parse_worker_and_progressive_material_removal',async()=>{
  await evaluate(`document.getElementById('gcode-start').click()`);
  await wait(`document.getElementById('status').textContent==='G-code 已讀入'&&!document.getElementById('gcode-start').disabled`,90000);
  assert.ok(await evaluate(`document.getElementById('download').hasAttribute('href')`));
  assert.ok((await evaluate(`document.getElementById('review').textContent`)).includes('G02/G03'));
  assert.ok((await evaluate(`document.getElementById('material-summary').textContent`)).includes('素材 s45c'));
  assert.equal(await evaluate(`document.getElementById('export-stl').disabled`),false);
  const before=await evaluate(`document.getElementById('material-summary').textContent`);
  assert.ok(before.includes('已除料 0 /'));
  const beforeShot=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:true});
  fs.writeFileSync(new URL('./gcode-before-removal.png',import.meta.url),Buffer.from(beforeShot.data,'base64'));
  await evaluate(`document.getElementById('sim-final').click()`);
  const after=await evaluate(`document.getElementById('material-summary').textContent`);
  assert.ok(!after.includes('已除料 0 /'));
  assert.equal(await evaluate(`document.getElementById('status').textContent`),'除料後工件');
  await evaluate(`document.getElementById('export-stl').click()`);
  await wait(`document.getElementById('toast').textContent.includes('近似 STL 已建立')`,15000);
  const afterShot=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:true});
  const afterBytes=Buffer.from(afterShot.data,'base64');
  fs.writeFileSync(new URL('./gcode-finished-piece.png',import.meta.url),afterBytes);
  assert.notEqual(crypto.createHash('sha256').update(Buffer.from(beforeShot.data,'base64')).digest('hex'),crypto.createHash('sha256').update(afterBytes).digest('hex'));
  for(const key of ['xy','xz','yz','3d'])assert.equal(await evaluate(`document.querySelector('[data-view="${key}"]').click();document.querySelector('[data-view="${key}"]').getAttribute('aria-selected')`),'true');
 });
 await test('gcode_stock_edit_revokes_old_result',async()=>{
  await evaluate(`document.getElementById('gcode-stock_z').value='21';document.getElementById('gcode-stock_z').dispatchEvent(new Event('input',{bubbles:true}))`);
  assert.equal(await evaluate(`document.getElementById('status').textContent`),'待規劃');
  assert.equal(await evaluate(`document.getElementById('download').hasAttribute('href')`),false);
 });
 await test('configured_initial_tool_tip_is_applied_in_browser',async()=>{
  await evaluate(`document.getElementById('gcode-initial_x').value='4';document.getElementById('gcode-initial_x').dispatchEvent(new Event('input',{bubbles:true}))`);
  await evaluate(`document.getElementById('gcode-initial_y').value='2';document.getElementById('gcode-initial_y').dispatchEvent(new Event('input',{bubbles:true}))`);
  await evaluate(`document.getElementById('gcode-start').click()`);
  await wait(`document.getElementById('status').textContent==='G-code 已讀入'&&!document.getElementById('gcode-start').disabled`,90000);
  assert.ok((await evaluate(`document.getElementById('review').textContent`)).includes('X4 Y2'));
  assert.ok((await evaluate(`document.getElementById('coordinates').textContent`)).includes('X 4.000'));
 });
 await test('unsupported_gcode_is_rejected_in_browser',async()=>{
  await evaluate(`(()=>{const dt=new DataTransfer();dt.items.add(new File(['G21 G90\\nG83 X10 Y10 Z-5 R2 Q1 F100\\nM30'],'bad.nc',{type:'text/plain'}));const f=document.getElementById('gcode-file');f.files=dt.files;f.dispatchEvent(new Event('change',{bubbles:true}))})()`);
  await wait(`document.getElementById('gcode-name').textContent==='bad.nc'`,15000);
  await evaluate(`document.getElementById('gcode-start').click()`);
  await wait(`document.getElementById('toast').textContent.includes('未支援') && !document.getElementById('gcode-start').disabled`,20000);
  assert.equal(await evaluate(`document.getElementById('download').hasAttribute('href')`),false);
 });
 assert.deepEqual(errors,[],'No JS uncaught runtime or network loading errors');
 const result={pass:true,checks,console_errors:errors,date:new Date().toISOString()};
 fs.writeFileSync(new URL('./browser-ui-acceptance.json',import.meta.url),JSON.stringify(result,null,2));
 console.log(JSON.stringify(result,null,2));
}finally{ws.close();}
