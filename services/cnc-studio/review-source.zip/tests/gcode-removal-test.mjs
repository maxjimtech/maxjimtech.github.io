import assert from 'node:assert/strict';
import fs from 'node:fs';
import {parseGcode} from '../gcode-import.mjs';
import {simulateStock} from '../material-sim.mjs';
import {simulationFrame,renderStock} from '../stock-view.mjs';
import {stockAsSTL} from '../stock-stl.mjs';
import {buildPlan,defaultSettings,gcode} from '../cam.mjs';

const cat=JSON.parse(fs.readFileSync(new URL('../catalog.json',import.meta.url)));
const code=fs.readFileSync(new URL('../examples/removal-demo.nc',import.meta.url),'utf8');
const imported=parseGcode(code,cat);
const cfg={x:80,y:60,z:20,top_z:0,resolution_mm:1,material:'al6061'};
const sim=simulateStock(imported.moves,cat,cfg);
const checks=[];
function test(name,fn){fn();checks.push(name);console.log('PASS',name);}

test('real_fanuc_sample_import',()=>{
 assert.ok(imported.moves.length>=15);
 assert.equal(imported.operations.length,1);
 assert.equal(imported.operations[0].tool,'em6');
 assert.equal(imported.source,'IMPORTED_GCODE');
 assert.equal(imported.blockers.length,0);
});
test('material_removed_and_finished_workpiece',()=>{
 assert.ok(sim.removed_mm3>5000&&sim.removed_mm3<15000);
 assert.ok(sim.remaining_mm3<80*60*20);
 assert.ok(sim.remaining_mm3>0);
 assert.equal(sim.frames.length,61);
 assert.equal(sim.nx,80);assert.equal(sim.ny,60);
 assert.equal(sim.frames[0].removed_mm3,0);
 assert.ok(sim.frames.at(-1).removed_mm3>0);
 assert.equal(sim.remaining_pct<100,true);
});
test('removal_is_monotone_and_initial_stock_is_flat',()=>{
 assert.ok(sim.frames[0].heights.every(z=>z===0));
 for(let k=1;k<sim.frames.length;k++){
  assert.ok(sim.frames[k].removed_mm3>=sim.frames[k-1].removed_mm3);
  for(let i=0;i<sim.nx*sim.ny;i++)assert.ok(sim.frames[k].heights[i]<=sim.frames[k-1].heights[i]+1e-4);
 }
});
test('actual_material_changes_mass_but_not_shape',()=>{
 const steel=simulateStock(imported.moves,cat,{...cfg,material:'s45c'});
 assert.ok(Math.abs(steel.removed_mm3-sim.removed_mm3)<1e-3);
 assert.ok(steel.removed_mass_g>sim.removed_mass_g*2);
});
test('mm_inch_and_incremental_motion',()=>{
 const p=parseGcode('G20 G90 G0 X1 Y1 Z.5\nG91 G1 X1 F10\nM30',cat,{initial_z:20});
 assert.deepEqual(p.moves[0].b,[25.4,25.4,12.7]);
 assert.equal(p.moves[1].b[0],50.8);
 assert.equal(p.moves[1].feed,254);
});
test('tool_change_fanuc_multitool_catalog',()=>{
 const p=parseGcode('G21 G90 G0 Z10\nT01 M06\nG1 Z-1 F100\nG0 Z10\nT04 M06\nG0 X25\nG1 Z-2 F100\nM30',cat);
 assert.equal(p.operations.length,2);
 assert.equal(p.operations[0].tool,'em6');assert.equal(p.operations[1].tool,'ball6');
});
test('strictly_reject_unsupported_or_dangerous_codes',()=>{
 for(const unsupported of ['G83 Z-10 R2','G28 G91 Z0','G41 D1 X20','G5 X5','G53 G0 X0','G55 G0 X0','G0 A90','G1 X[#1+5]','M98 P1000']){
  assert.throws(()=>parseGcode(unsupported,cat),/不支援|未支援|巨集|軸|補正|循環/);
 }
 assert.throws(()=>parseGcode('T99 M06\nG0 Z10',cat),/刀具資料庫/);
 assert.throws(()=>parseGcode('G21 G90\nG1 X12 Z-2',cat),/缺少有效 F/);
 for(const invalid of ['G20 G21 G0 X1','G90 G91 G0 X1','G0 X2 M30','T1 M06 G0 Z10','M06 M06 T1 G0 Z10'])
  assert.throws(()=>parseGcode(invalid,cat),/衝突|不可同時|重複/);
});
test('g02_g03_xy_ijk_and_r_are_tessellated_with_endpoints_preserved',()=>{
 const p=parseGcode('G21 G17 G90 G0 X10 Y10 Z2\nG1 Z-2 F300\nG3 X20 Y20 I0 J10 F600\nG2 X30 Y10 R10\nM30',cat);
 assert.equal(p.arc_summary.blocks,2);
 assert.ok(p.arc_summary.segments>30);
 assert.deepEqual(p.moves.at(-1).b,[30,10,-2]);
 assert.ok(p.moves.some(m=>m.source_mode==='G3'));
 assert.ok(p.moves.some(m=>m.source_mode==='G2'));
 for(const m of p.moves.filter(m=>m.arc_block===1))assert.ok(Math.abs(Math.hypot(m.b[0]-10,m.b[1]-20)-10)<1e-4);
});
test('full_circle_absolute_center_and_major_radius_modes',()=>{
 const full=parseGcode('G21 G17 G90 G0 X10 Y0 Z-1\nG1 X10 F200\nG90.1 G2 X10 Y0 I0 J0 F200\nM30',cat);
 assert.equal(full.arc_summary.blocks,1);
 assert.ok(full.arc_summary.segments>=72);
 assert.deepEqual(full.moves.at(-1).b,[10,0,-1]);
 const minor=parseGcode('G21 G17 G90 G0 X0 Y0 Z-1\nG2 X10 Y0 R8 F200\nM30',cat);
 const major=parseGcode('G21 G17 G90 G0 X0 Y0 Z-1\nG2 X10 Y0 R-8 F200\nM30',cat);
 assert.ok(major.arc_summary.segments>minor.arc_summary.segments);
});
test('g18_g19_helical_arcs_interpolate_third_axis',()=>{
 const xz=parseGcode('G21 G18 G90 G0 X10 Y0 Z0\nG3 X20 Y5 Z-10 I10 K0 F200\nM30',cat);
 assert.deepEqual(xz.moves.at(-1).b,[20,5,-10]);
 assert.ok(xz.moves.some(m=>m.b[1]>0&&m.b[1]<5));
 const yz=parseGcode('G21 G19 G90 G0 X0 Y10 Z0\nG3 X5 Y20 Z-10 J10 K0 F200\nM30',cat);
 assert.deepEqual(yz.moves.at(-1).b,[5,20,-10]);
 assert.ok(yz.moves.some(m=>m.b[0]>0&&m.b[0]<5));
});
test('arc_validation_rejects_ambiguous_or_inconsistent_geometry',()=>{
 for(const bad of [
  'G21 G17 G90 G0 X0 Y0\nG2 X10 Y0 I5 J0 R5 F100',
  'G21 G17 G90 G0 X0 Y0\nG2 X10 Y0 I2 J0 F100',
  'G21 G17 G90 G0 X0 Y0\nG2 X0 Y0 R5 F100',
  'G21 G18 G90 G0 X0 Y0 Z0\nG2 X10 Z0 J5 F100'
 ])assert.throws(()=>parseGcode(bad,cat),/圓弧|半徑|中心|不可使用/);
});
test('circular_cut_removes_curved_groove_and_finished_stock',()=>{
 const p=parseGcode('G21 G17 G90 G0 X30 Y20 Z5\nG1 Z-3 F150\nG2 X30 Y20 I-10 J0 F400\nG0 Z5\nM30',cat);
 const s=simulateStock(p.moves,cat,{x:50,y:40,z:10,top_z:0,resolution_mm:.5,material:'al6061'});
 assert.ok(s.removed_mm3>400&&s.removed_mm3<2500);
 assert.equal(s.frames.length,61);
 assert.ok(s.frames.at(-1).heights.some(z=>z<-2.5));
});
test('explicit_initial_tool_tip_is_respected',()=>{
 const p=parseGcode('G21 G90 G0 X5\nG1 Y8 F100\nM30',cat,{initial_x:3,initial_y:4,initial_z:18});
 assert.deepEqual(p.moves[0].a,[3,4,18]);
 assert.deepEqual(p.moves[1].b,[5,8,18]);
 assert.ok(p.warnings.some(w=>w.includes('X3 Y4 Z18')));
});
test('noncutting_rapid_never_removes_stock',()=>{
 const p=parseGcode('G21 G90 G0 X10 Y10 Z-3\nG0 X50 Y20 Z-3\nM30',cat);
 const s=simulateStock(p.moves,cat,cfg);
 assert.equal(s.removed_mm3,0);
 assert.ok(s.rapid_risk_segments>=1);
});
test('long_rapid_crossing_narrow_blank_is_detected',()=>{
 const small={x:8,y:8,z:5,top_z:0,resolution_mm:.5,material:'al6061'};
 const s=simulateStock([{a:[-1000,4,-2],b:[1000,4,-2],mode:'G0',tool:'em6'}],cat,small);
 assert.equal(s.removed_mm3,0);
 assert.equal(s.rapid_risk_segments,1);
});
test('ball_and_drill_have_conical_or_spherical_footprints',()=>{
 const step=[{a:[4,4,10],b:[4,4,-2],mode:'G1',tool:'ball6',feed:200}];
 const small={x:8,y:8,z:5,top_z:0,resolution_mm:.5,material:'al6061'};
 const b=simulateStock(step,cat,small),last=b.frames.at(-1).heights;
 const at=(x,y)=>last[y*b.nx+x];
 assert.ok(at(7,7)<at(3,7),'ball-center lower than rounded outer edge');
 const f=simulateStock([{...step[0],tool:'em6'}],cat,small).frames.at(-1).heights;
 assert.ok(Math.abs(f[7*b.nx+7]-f[7*b.nx+3])<.001);
 const drill=simulateStock([{...step[0],tool:'drill12'}],cat,small).frames.at(-1).heights;
 assert.ok(drill[7*b.nx+7]<drill[7*b.nx+2]);
});
test('render_3d_xy_xz_yz_from_real_simulation_frames',()=>{
 let drawn=0;const ctx={beginPath(){},moveTo(){},lineTo(){},closePath(){},fill(){drawn++;},stroke(){},fillRect(){drawn++;},set fillStyle(v){},set strokeStyle(v){},set lineWidth(v){}};
 const project=p=>[p[0],p[1]-p[2],p[2]];
 for(const mode of ['3d','xy','xz','yz'])renderStock(ctx,sim,1,mode,project);
 assert.ok(drawn>80);
 assert.equal(simulationFrame(sim,0),sim.frames[0]);
 assert.equal(simulationFrame(sim,1),sim.frames.at(-1));
});
test('generated_fanuc_program_import_reproduces_original_toolpath',()=>{
 const model=JSON.parse(fs.readFileSync(new URL('./reference/browser_geometry.json',import.meta.url)));
 const planned=buildPlan(model,defaultSettings(model),cat);
 const parsed=parseGcode(gcode({...planned,id:'roundtrip'},cat),cat,{initial_z:planned.settings.safe_z});
 assert.deepEqual(parsed.moves.map(m=>m.b),planned.moves.map(m=>m.b));
 assert.deepEqual(parsed.moves.map(m=>m.tool),planned.moves.map(m=>m.tool));
});
test('final_heightfield_exports_approximate_binary_stl',()=>{
 const mesh=stockAsSTL(sim),view=new DataView(mesh.buffer);
 assert.ok(mesh.triangles>sim.nx*sim.ny*4);
 assert.equal(view.getUint32(80,true),mesh.triangles);
 assert.equal(mesh.buffer.byteLength,84+mesh.triangles*50);
 assert.equal(mesh.approximate,true);
 for(let at=84;at<mesh.buffer.byteLength;at+=50)for(let k=0;k<12;k++)assert.ok(Number.isFinite(view.getFloat32(at+4*k,true)));
});
test('exported_mesh_has_opposed_shared_edges_and_correct_volume',()=>{
 const {buffer,triangles}=stockAsSTL(sim),data=new DataView(buffer),edges=new Map();
 let volume=0,zeroArea=0;
 const point=(at)=>[data.getFloat32(at,true),data.getFloat32(at+4,true),data.getFloat32(at+8,true)];
 for(let t=0;t<triangles;t++){
  const at=84+t*50,pts=[point(at+12),point(at+24),point(at+36)];
  const [a,b,c]=pts,u=b.map((v,i)=>v-a[i]),v=c.map((x,i)=>x-a[i]);
  const n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];
  if(Math.hypot(...n)<1e-8)zeroArea++;
  volume+=(a[0]*n[0]+a[1]*n[1]+a[2]*n[2])/6;
  for(let i=0;i<3;i++){
   const from=pts[i].join(','),to=pts[(i+1)%3].join(','),key=[from,to].sort().join('|');
   let e=edges.get(key);if(!e)edges.set(key,e={count:0,balance:0});
   e.count++;e.balance+=from<to?1:-1;
  }
 }
 const open=[...edges.values()].filter(e=>e.count!==2||e.balance!==0);
 assert.equal(zeroArea,0,'STL must not contain zero-area triangles');
 assert.equal(open.length,0,`STL has ${open.length} non-manifold / unmatched edges`);
 assert.ok(Math.abs(volume-sim.remaining_mm3)/sim.remaining_mm3<.001,`STL volume ${volume} vs heightfield ${sim.remaining_mm3}`);
});
test('stepped_surface_corner_stays_watertight',()=>{
 const custom={nx:2,ny:2,dx:1,dy:1,bottom_z:-10,frames:[{heights:Float32Array.from([0,-2,-3,-5])}]};
 const mesh=stockAsSTL(custom),data=new DataView(mesh.buffer),edges=new Map();
 for(let i=0;i<mesh.triangles;i++){
  const at=84+50*i,point=k=>[0,4,8].map(offset=>data.getFloat32(at+12+12*k+offset,true)).join(',');
  const p=[point(0),point(1),point(2)];
  for(let j=0;j<3;j++){
   const a=p[j],b=p[(j+1)%3],key=[a,b].sort().join('|');
   let record=edges.get(key);if(!record)edges.set(key,record={count:0,sign:0});
   record.count++;record.sign+=a<b?1:-1;
  }
 }
 assert.equal([...edges.values()].filter(v=>v.count!==2||v.sign!==0).length,0);
});

console.log(JSON.stringify({pass:true,checks:checks.length,gcode_moves:imported.moves.length,removed_mm3:sim.removed_mm3,remaining_mm3:sim.remaining_mm3,frames:sim.frames.length},null,2));
