import {wasmBinary} from './wasm-node.mjs';
import {createRequire} from 'node:module';import fs from 'node:fs';import assert from 'node:assert/strict';
import {analyzeSTEP} from '../kernel.mjs';
const require=createRequire(import.meta.url),init=require('./occt-node.cjs');
const oc=await init({wasmBinary:wasmBinary}),checks=[];
for(const name of ['alternate','sphere','blind_hole','boss','multi','open_face']){
 let model,error;try{model=analyzeSTEP(oc,fs.readFileSync(new URL(`./fixtures/${name}.step`,import.meta.url)),name+'.step');}catch(e){error=String(e.message||e);}
 if(name==='alternate'){assert.ok(!error,error);assert.equal(model.supported,true);assert.deepEqual(model.size,[80,60,18]);assert.equal(model.features.length,3);assert.equal(model.difference_mm3,0);fs.writeFileSync(new URL('./output/browser_alternate_geometry.json',import.meta.url),JSON.stringify(model));}
 else assert.ok(error||!model.supported,name+' must be blocked');
 checks.push({name,pass:true,supported:model?.supported??false,error,difference:model?.difference_mm3});
}
// Same WASM process repeatedly reads distinct STEP files, after disposal.
for(let i=0;i<3;i++){const m=analyzeSTEP(oc,fs.readFileSync(new URL('../examples/demo.step',import.meta.url)));assert.equal(m.supported,true);assert.equal(m.features.length,5);}
checks.push({name:'three_repeat_imports_after_cleanup',pass:true});
fs.writeFileSync(new URL('./output/browser_geometry_acceptance.json',import.meta.url),JSON.stringify({pass:true,checks},null,2));console.log(JSON.stringify({pass:true,checks}));
