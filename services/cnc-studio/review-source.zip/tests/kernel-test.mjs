import {wasmBinary} from './wasm-node.mjs';
import {createRequire} from 'node:module';
import fs from 'node:fs';
import {analyzeSTEP} from '../kernel.mjs';
const require=createRequire(import.meta.url);const init=require('./occt-node.cjs');
const oc=await init({wasmBinary:wasmBinary});
const bytes=fs.readFileSync(new URL('../examples/demo.step',import.meta.url));
try{const result=analyzeSTEP(oc,bytes);console.log(JSON.stringify({...result,vertices:result.vertices.length,triangles:result.triangles.length},null,2));fs.writeFileSync(new URL('./reference/browser_geometry.json',import.meta.url),JSON.stringify(result));}catch(e){console.error(e);process.exitCode=1;}
