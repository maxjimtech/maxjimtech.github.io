import assert from 'node:assert/strict';
import fs from 'node:fs';
import {defaultSettings,buildPlan,chooseMachine,gcode} from '../cam.mjs';
import {recommendLite,applyLiteAdvice,confirmLiteReview,REVIEW_BLOCKER} from '../decision-lite.mjs';

const read=relative=>JSON.parse(fs.readFileSync(new URL(relative,import.meta.url)));
const model=read('./reference/browser_geometry.json'),catalog=read('../catalog.json');
const settings=defaultSettings(model),checks=[];
function test(name,fn){checks.push({name,pass:true});return Promise.resolve().then(fn).then(()=>console.log('PASS',name));}
// Test scores are deliberately artificial. They validate decision plumbing, NOT live ONNX inference.
const mockEmbed=async texts=>texts.map((_,i)=>i===0?[1,0,0]:i===1?[.95,.05,0]:[.4,.8,.1]);

await test('bounded_full_job_machine_tool_strategy',async()=>{
 const advice=await recommendLite({model,settings,catalog,auto_machine:true},mockEmbed);
 assert.equal(advice.status,'MODEL_RESULT');
 assert.deepEqual(Object.keys(advice.answers),['tool','machine','strategy']);
 assert.ok(advice.allowed_tool_ids.includes(advice.answers.tool.choice));
 assert.ok(advice.allowed_machine_ids.includes(advice.answers.machine.choice));
 assert.equal(advice.answers.strategy.choice,'raster');
 assert.equal(advice.review_required,true);
 const chosen={...settings,tool:advice.answers.tool.choice,machine:advice.answers.machine.choice};
 const plan=buildPlan(model,chosen,catalog,advice.answers.strategy.choice);
 plan.id='test';applyLiteAdvice(plan,advice);
 assert.equal(plan.status,'BLOCKED');assert.ok(plan.blockers.includes(REVIEW_BLOCKER));
 assert.throws(()=>gcode(plan,catalog));assert.equal(plan.nc,undefined);
 confirmLiteReview(plan,catalog);
 assert.equal(plan.status,'DRAFT');assert.ok(plan.nc?.includes('G54'));
 assert.equal(plan.nc,gcode(plan,catalog));
 assert.ok(plan.ai.user_reviewed_at);assert.throws(()=>confirmLiteReview(plan,catalog));
});

await test('manual_machine_stays_locked',async()=>{
 const choice=await recommendLite({model,settings:{...settings,machine:'vmc850'},catalog,auto_machine:false},mockEmbed);
 assert.equal(choice.effective_machine_selection,'manually-locked');
 const plan=buildPlan(model,{...settings,machine:'vmc850',tool:choice.answers.tool.choice},catalog,choice.answers.strategy.choice);
 applyLiteAdvice(plan,choice);assert.equal(plan.settings.machine,'vmc850');
});

await test('geometry_restricts_tool_diameter',async()=>{
 const compact={...model,features:[{id:'F1',kind:'pocket',w:8,h:8,depth:6,x:10,y:10}]};
 const selected=await recommendLite({model:compact,settings,catalog,auto_machine:true},mockEmbed);
 assert.deepEqual(selected.allowed_tool_ids,['em6']);
 assert.equal(selected.answers.tool.method,'single-valid-choice');
});

await test('large_stock_restricts_machine_travel',async()=>{
 const large={...settings,stock_x:1000,stock_y:550};
 const selected=await recommendLite({model,settings:large,catalog,auto_machine:true},mockEmbed);
 assert.deepEqual(selected.allowed_machine_ids,['vmc1160']);
 assert.equal(selected.answers.machine.choice,'vmc1160');
});

await test('fixture_blocker_cannot_be_overridden',async()=>{
 const advice=await recommendLite({model,settings,catalog,auto_machine:true},mockEmbed);
 const unsafe={...settings,tool:advice.answers.tool.choice,machine:advice.answers.machine.choice,fixture_boxes:[[48,32,1,52,36,40]]};
 const plan=buildPlan(model,unsafe,catalog,advice.answers.strategy.choice);
 assert.equal(plan.status,'BLOCKED');
 applyLiteAdvice(plan,advice);confirmLiteReview(plan,catalog);
 assert.equal(plan.status,'BLOCKED');assert.ok(plan.blockers.some(s=>s.includes('治具')));
 assert.equal(plan.nc,undefined);assert.throws(()=>gcode(plan,catalog));
});

await test('unsupported_geometry_blocks_model',async()=>{
 await assert.rejects(recommendLite({model:{...model,supported:false},settings,catalog,auto_machine:true},mockEmbed),/幾何/);
});

await test('invalid_vectors_and_tool_tampering_fail_closed',async()=>{
 await assert.rejects(recommendLite({model,settings,catalog,auto_machine:true},async()=>[[0],[0]]),/數量錯誤/);
 const advice=await recommendLite({model,settings,catalog,auto_machine:true},mockEmbed);
 const plan=buildPlan(model,{...settings,tool:'em10',machine:advice.answers.machine.choice},catalog,advice.answers.strategy.choice);
 if(plan.settings.tool!==advice.answers.tool.choice)assert.throws(()=>applyLiteAdvice(plan,advice),/銑刀/);
});

const report={version:'0.3.0-dev.2',pass:true,tests:checks,scope:'Offline deterministic integration only; MiniLM model and CDN were not loaded or benchmarked.',
 production_publish_allowed:false,reason:'Live browser ONNX inference remains untested'};
fs.writeFileSync(new URL('./output/browser_lite_acceptance_dev2.json',import.meta.url),JSON.stringify(report,null,2));
console.log(JSON.stringify({pass:true,checks:checks.length,model_live_tested:false}));
