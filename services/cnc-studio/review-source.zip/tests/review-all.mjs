import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import crypto from 'node:crypto';
const root=fileURLToPath(new URL('../',import.meta.url)),round=Number(process.argv[2]);
if(![1,2,3].includes(round))throw Error('Usage: node tests/review-all.mjs 1|2|3');
const tests=['kernel-test.mjs','geometry-cases.mjs','cam-test.mjs','lite-test.mjs','surface-test.mjs','gcode-removal-test.mjs','parity-test.mjs','sixaxis-test.mjs','browser-ui-test.mjs','sixaxis-ui-test.mjs'];
const testDir=path.join(root,'tests',`review-round-${round}`);fs.mkdirSync(testDir,{recursive:true});const results=[];
function hashes(dir,prefix=''){let out=[];for(const entry of fs.readdirSync(dir,{withFileTypes:true})){const name=prefix+entry.name;if(name==='tests'||name==='vendor/occ')continue;if(entry.isDirectory())out.push(...hashes(path.join(dir,entry.name),name+'/'));else if(/\.(mjs|js|html|css|json|nc|step|gz|wasm)$/.test(name)&&!name.startsWith('review-report'))out.push({path:name,sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(dir,entry.name))).digest('hex')});}return out;}
const before=hashes(root),started=new Date().toISOString();
for(const test of tests){const t=Date.now(),r=spawnSync(process.execPath,['tests/'+test],{cwd:root,env:{...process.env,CNC_REVIEW_ROUND:String(round),CNC_CDP_ENDPOINT:'http://127.0.0.1:9338',CNC_PORT:'8897'},encoding:'utf8',timeout:240000,maxBuffer:15*1024*1024});
 fs.writeFileSync(path.join(testDir,test+'.log'),r.stdout+'\n'+r.stderr);const count=test==='kernel-test.mjs'?1:test==='geometry-cases.mjs'?JSON.parse(r.stdout.trim()).checks.length:(r.stdout.match(/^PASS /gm)||[]).length;
 const item={test,pass:r.status===0,checks:count,duration_ms:Date.now()-t};results.push(item);console.log(JSON.stringify(item));
 if(r.status!==0){console.error(r.stdout.slice(-5000),r.stderr);fs.writeFileSync(path.join(testDir,'results.json'),JSON.stringify({round,pass:false,results},null,2));process.exit(1);}
}
const after=hashes(root);if(JSON.stringify(before)!==JSON.stringify(after))throw Error('Runtime files changed during review');
const result={round,pass:true,started,ended:new Date().toISOString(),checks:results.reduce((s,r)=>s+r.checks,0),results,files:after};fs.writeFileSync(path.join(testDir,'results.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify({round,pass:true,checks:result.checks}));
