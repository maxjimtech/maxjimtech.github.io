// Local-only static server for real browser acceptance of module Workers and WASM.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(fileURLToPath(new URL('../',import.meta.url)));
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.wasm':'application/wasm','.step':'application/octet-stream','.stp':'application/octet-stream'};
http.createServer((req,res)=>{
 const requested=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
 const target=path.resolve(root,'.'+(requested==='/'?'/index.html':requested));
 if(!target.startsWith(root+path.sep)){res.writeHead(403).end();return;}
 fs.stat(target,(err,stat)=>{
  if(err||!stat.isFile()){res.writeHead(404).end();return;}
  res.setHeader('Content-Type',types[path.extname(target)]||'application/octet-stream');
  res.setHeader('Cache-Control','no-store');
  fs.createReadStream(target).pipe(res);
 });
}).listen(Number(process.env.CNC_PORT||8892),'127.0.0.1',()=>console.log('CNC v0.6 arc and generalized-surface local server'));
