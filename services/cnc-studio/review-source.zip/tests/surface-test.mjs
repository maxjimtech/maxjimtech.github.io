import {wasmBinary} from './wasm-node.mjs';
// Standalone real STEP + WASM surface regression; no actual machine execution.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createRequire} from 'node:module';
import {analyzeSTEP} from '../kernel.mjs';
import {defaultSettings,buildPlan,gcode} from '../cam.mjs';
import {surfaceIndex,inspectSurface,toolTipHeight,flatToolTipHeight,buildSurfacePlan} from '../surface.mjs';
import {simulateStock} from '../material-sim.mjs';

const require=createRequire(import.meta.url);
const oc=await require('./occt-node.cjs')({wasmBinary:wasmBinary});
const catalog=JSON.parse(fs.readFileSync(new URL('../catalog.json',import.meta.url)));
const bytes=fs.readFileSync(new URL('./fixtures/surface_trough.step',import.meta.url));
const model=analyzeSTEP(oc,bytes,'surface_trough.step');
const loadModel=name=>analyzeSTEP(oc,fs.readFileSync(new URL(`./fixtures/${name}.step`,import.meta.url)),name+'.step');
const blindHole=loadModel('blind_hole'),boss=loadModel('boss'),alternate=loadModel('alternate'),sphere=loadModel('sphere');
const settings={...defaultSettings(model),tool:'ball6'};
const options={pre_roughed:true,stepover_mm:.9,sample_mm:1,finish_allowance_mm:.15};
const checks=[];
function test(name,fn){fn();checks.push(name);console.log('PASS',name);}
function build(setting=settings,option=options){return buildSurfacePlan(model,setting,catalog,option);}

test('real_step_valid_single_solid',()=>{
 assert.equal(model.audit.valid,true);
 assert.equal(model.audit.solid_count,1);
 assert.ok(model.size[0]>=79.99&&model.size[0]<=80.01);
 assert.equal(model.size[1],60);
});
test('concave_step_heightfield',()=>{
 const info=inspectSurface(model);
 assert.equal(info.supported,true);
 assert.ok(info.triangles>=10);
 assert.ok(info.lowest_z < -5 && info.lowest_z > -20);
 assert.equal(info.projected_xy_area_mm2,4800);
 const index=surfaceIndex(model);
 assert.ok(index.at(40,30)<index.at(40,0));
});
test('ball_tool_clearance_and_mesh_allowance',()=>{
 const index=surfaceIndex(model),r=3,offset=.55;
 for(const xy of [[15,30],[40,30],[65,20],[20,40]]){
  const tip=toolTipHeight(index,...xy,r,offset);
  assert.ok(tip>=index.at(...xy)+offset-1e-4,'tool tip above direct contact point');
 }
});
test('flat_tool_clearance_respects_curves_and_vertical_steps',()=>{
 const index=surfaceIndex(model),r=3,offset=.8;
 for(const xy of [[15,30],[40,30],[65,20]])assert.ok(flatToolTipHeight(index,...xy,r,offset)>=index.at(...xy)+offset-1e-4);
});
const finish=build();
test('surface_raster_has_feeds_operations_and_draft',()=>{
 assert.equal(finish.operations.length,1);
 assert.equal(finish.operations[0].tool,'ball6');
 assert.ok(finish.moves.length>1000);
 assert.equal(finish.status,'DRAFT');
 assert.equal(finish.blockers.length,0);
 assert.equal(finish.strategy,'surface_raster');
 assert.ok(finish.surface_settings.unmachined_border_mm>=3);
});
test('nc_and_simulation_share_every_coordinate',()=>{
 const lines=gcode({...finish,id:'TEST'},catalog).split('\n');
 const points=lines.filter(x=>/^G[01] X/.test(x)).map(s=>[...s.matchAll(/[XYZ](-?[\d.]+)/g)].map(m=>Number(m[1])));
 assert.deepEqual(points,finish.moves.map(move=>move.b));
 assert.ok(lines.some(x=>x.includes('BALL-NOSE FINISH')));
 assert.ok(lines.some(x=>x.includes('T04 M06')));
});
test('rapid_xy_always_at_safe_z',()=>{
 for(const move of finish.moves)if(move.mode==='G0'&&move.a.slice(0,2).some((n,i)=>n!==move.b[i])){
  assert.ok(move.a[2]>=settings.safe_z-1e-4);
  assert.ok(move.b[2]>=settings.safe_z-1e-4);
 }
});
test('integrated_flat_roughing_then_ball_finish_without_prerough',()=>{
 const p=build(settings,{...options,pre_roughed:false});
 assert.equal(p.status,'DRAFT');
 assert.equal(p.operations.length,2);
 assert.equal(p.operations[0].tool,'em6');
 assert.equal(p.operations[1].tool,'ball6');
 assert.ok(p.moves.some(m=>m.tool==='em6'&&m.b[2]<-5));
 const nc=gcode({...p,id:'INTEGRATED'},catalog);
 assert.ok(nc.includes('T01 M06')&&nc.includes('T04 M06'));
});
test('fixture_intersection_blocks_nc',()=>{
 const p=build({...settings,fixture_boxes:[[38,28,-5,42,32,40]]});
 assert.ok(p.collisions.length>0);
 assert.equal(p.status,'BLOCKED');
 assert.throws(()=>gcode(p,catalog));
});
test('wrong_tool_and_invalid_parameters_rejected',()=>{
 assert.throws(()=>build({...settings,tool:'em6'}),/球頭/);
 for(const bad of [{stepover_mm:.01},{sample_mm:0},{finish_allowance_mm:1.1}])assert.throws(()=>build(settings,{...options,...bad}));
});
test('stock_clearance_and_travel_block',()=>{
 assert.equal(build({...settings,stock_x:90}).status,'BLOCKED');
 assert.equal(build({...settings,safe_z:2}).status,'BLOCKED');
 assert.equal(build({...settings,machine_limits:{travel:[50,50,50]}}).status,'BLOCKED');
});
test('unsupported_step_is_rejected',()=>{
 assert.equal(inspectSurface(sphere).supported,false);
 assert.throws(()=>buildSurfacePlan(sphere,{...defaultSettings(sphere),tool:'ball6'},catalog,options),/倒扣|向下表面/);
 const disconnected={...model,triangles:[]};
 assert.equal(inspectSurface(disconnected).supported,false);
});
test('top_accessible_blind_hole_boss_and_deep_step_share_one_engine',()=>{
 assert.equal(inspectSurface(blindHole).supported,true);
 assert.equal(inspectSurface(boss).supported,true);
 assert.equal(inspectSurface(alternate).supported,true);
 const holeIndex=surfaceIndex(blindHole),bossIndex=surfaceIndex(boss),mixedIndex=surfaceIndex(alternate);
 assert.ok(holeIndex.at(20,20)<-7,'blind hole floor is sampled');
 assert.ok(bossIndex.at(20,20)>bossIndex.at(40,30)+3.5,'raised boss remains above surrounding plane');
 assert.ok(mixedIndex.at(39,30)<-5.5,'deep rectangular slot/pocket floor is sampled');
 assert.ok(mixedIndex.at(12,12)<-17.5,'through hole projects to stock bottom');
 const holePlan=buildSurfacePlan(blindHole,{...defaultSettings(blindHole),tool:'ball6'},catalog,{...options,pre_roughed:false});
 assert.equal(holePlan.status,'DRAFT');
 assert.ok(holePlan.moves.some(m=>m.b[2]<-6));
 const sim=simulateStock(holePlan.moves,catalog,{x:holePlan.settings.stock_x,y:holePlan.settings.stock_y,z:holePlan.settings.stock_z,top_z:holePlan.settings.stock_z-blindHole.size[2],resolution_mm:1,material:holePlan.settings.material});
 assert.ok(sim.removed_mm3>1000&&sim.remaining_mm3>0);
 assert.ok(Math.min(...sim.frames.at(-1).heights)<-6);
});
test('legacy_plan_not_broken_by_surface_additions',()=>{
 const roughModel=JSON.parse(fs.readFileSync(new URL('./reference/browser_geometry.json',import.meta.url)));
 const rough=buildPlan(roughModel,defaultSettings(roughModel),catalog);
 assert.equal(rough.operations.length,6);
 assert.equal(rough.moves.length,464);
 assert.equal(rough.status,'DRAFT');
});

console.log(JSON.stringify({pass:true,checks:checks.length,moves:finish.moves.length,mesh_triangles:model.surface.triangles},null,2));
