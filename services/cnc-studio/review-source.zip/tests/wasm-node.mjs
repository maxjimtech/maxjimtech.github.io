import fs from 'node:fs';
import {gunzipSync} from 'node:zlib';
import crypto from 'node:crypto';
const base=new URL('../vendor/',import.meta.url),manifest=JSON.parse(fs.readFileSync(new URL('occt-manifest.json',base)));
export const wasmBinary=gunzipSync(Buffer.concat(manifest.parts.map(p=>fs.readFileSync(new URL(p,base)))));
if(crypto.createHash('sha256').update(wasmBinary).digest('hex')!==manifest.sha256)throw Error('Test WASM hash mismatch');
